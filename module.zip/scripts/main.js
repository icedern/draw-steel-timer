let turnTimerInterval = null;

Hooks.on("updateCombat", async (combat, changed, options, userId) => {
    if (!combat.started || !combat.isActive) return;

    // Detect "End Turn" or Round Change -> Start Timer
    if (changed.turn !== undefined || changed.round !== undefined) {
        // In Draw Steel, "End Turn" usually creates a gap where we need to pick the next actor.
        startTimer();
    }
});

Hooks.on("updateCombatant", (combatant, changed, options, userId) => {
    // Stop timer if a combatant becomes "active"
    if (!combatant.combat?.active) return;

    // Check generic activation or Draw Steel specific flags
    const isActive = changed.flags?.["draw-steel"]?.activated || (combatant.combat.combatant?.id === combatant.id);

    if (isActive) {
        stopTimer();
    }
});

Hooks.on("deleteCombat", () => {
    stopTimer();
});

function startTimer() {
    stopTimer(); // Ensure no duplicate timers

    const duration = 30;
    let timeLeft = duration;

    // Create the timer element using standard DOM (v13 preferred)
    const timerDisplay = document.createElement("div");
    timerDisplay.id = "draw-steel-turn-timer";
    timerDisplay.innerText = timeLeft;
    document.body.appendChild(timerDisplay);

    turnTimerInterval = setInterval(() => {
        timeLeft--;
        const display = document.getElementById("draw-steel-turn-timer");
        
        // Safety check if element was removed manually
        if (!display) {
            clearInterval(turnTimerInterval);
            return;
        }

        display.innerText = timeLeft;

        // Flashy effect for last 10 seconds
        if (timeLeft <= 10) {
            display.classList.add("flashy");
        }

        if (timeLeft <= 0) {
            stopTimer();
        }
    }, 1000);
}

function stopTimer() {
    if (turnTimerInterval) {
        clearInterval(turnTimerInterval);
        turnTimerInterval = null;
    }
    
    // Remove element using standard DOM
    const display = document.getElementById("draw-steel-turn-timer");
    if (display) {
        display.remove();
    }
}